echo " Making Directory Hacking"
echo " Start "
echo " Please Wait "
echo " Processing... "
am start -n com.tencent.ig/com.epicgames.ue4.SplashActivity
sleep 5;
echo "=========================="
echo "Copying Data Tss MOD..."
echo "=========================="
cp -R /storage/emulated/0/IRGBrother/tss/comm.dat /data/data/com.tencent.ig/files/tss_tmp
cp -R /storage/emulated/0/IRGBrother/tss/config2.xml.b99a2eec /data/data/com.tencent.ig/files/tss_tmp
cp -R /storage/emulated/0/IRGBrother/tss/config3.xml /data/data/com.tencent.ig/files/tss_tmp
cp -R /storage/emulated/0/IRGBrother/tss/gp4.ano.dat /data/data/com.tencent.ig/files/tss_tmp
cp -R /storage/emulated/0/IRGBrother/tss/mn_cache.dat /data/data/com.tencent.ig/files/tss_tmp
cp -R /storage/emulated/0/IRGBrother/tss/mrpcs.data /data/data/com.tencent.ig/files/tss_tmp
cp -R /storage/emulated/0/IRGBrother/tss/tss.ano.dat /data/data/com.tencent.ig/files/tss_tmp
cp -R /storage/emulated/0/IRGBrother/tss/tss_base.dat /data/data/com.tencent.ig/files/tss_tmp
cp -R /storage/emulated/0/IRGBrother/tss/tss_cef.dat /data/data/com.tencent.ig/files/tss_tmp
cp -R /storage/emulated/0/IRGBrother/tss/tss_cfg2.dat /data/data/com.tencent.ig/files/tss_tmp
cp -R /storage/emulated/0/IRGBrother/tss/tss_emu_c2.dat /data/data/com.tencent.ig/files/tss_tmp
cp -R /storage/emulated/0/IRGBrother/tss/tss_lcp.dat /data/data/com.tencent.ig/files/tss_tmp
cp -R /storage/emulated/0/IRGBrother/tss/tss_r_record.dat /data/data/com.tencent.ig/files/tss_tmp
cp -R /storage/emulated/0/IRGBrother/tss/tss_shp_tmp.dat /data/data/com.tencent.ig/files/tss_tmp
cp -R /storage/emulated/0/IRGBrother/tss/tssmua.zip /data/data/com.tencent.ig/files/tss_tmp
cp -R /storage/emulated/0/IRGBrother/tss/tpp.s /data/data/com.tencent.ig/files/tss_tmp
cp -R /storage/emulated/0/IRGBrother/tss/tersafe.update /data/data/com.tencent.ig/files/tss_tmp
echo " Successfully.........." 
echo "=========================="
echo "Removing Lib PUBG..."
echo "=========================="
sleep 1;
rm -rf /data/data/com.tencent.ig/lib/libgcloud.so
rm -rf /data/data/com.tencent.ig/lib/libtersafe.so
rm -rf /data/data/com.tencent.ig/lib/libhelpshiftlistener.so
rm -rf /data/data/com.tencent.ig/lib/libIMSDK.so
rm -rf /data/data/com.tencent.ig/lib/libUE4.so
rm -rf /data/data/com.tencent.ig/lib/libBugly.so
rm -rf /data/data/com.tencent.ig/lib/libtprt.so
rm -rf /data/data/com.tencent.ig/lib/libTDataMaster.so
rm -rf /data/data/com.tencent.ig/lib/libzip.so
rm -rf /data/data/com.tencent.ig/lib/libzlib.so
echo " Successfully.........." 
echo "Loading. . .
█ 1%
██ 10%
███ 20%
████ 30%
█████ 40%
██████ 50%
███████ 60%
████████ 70%
█████████ 80 %
██████████ 90%
Loading . . .
████████████100% Success"
echo "=========================="
echo "Copying Mod Lib"
echo "=========================="
sleep 1;
cp -R /storage/emulated/0/IRGBrother/mod/libtersafe.so /data/data/com.tencent.ig/lib
cp -R /storage/emulated/0/IRGBrother/mod/libtprt.so /data/data/com.tencent.ig/lib
cp -R /storage/emulated/0/IRGBrother/mod/libzlib.so /data/data/com.tencent.ig/lib
cp -R /storage/emulated/0/IRGBrother/mod/llibzip.so /data/data/com.tencent.ig/lib
cp -R /storage/emulated/0/IRGBrother/mod/libabase.so /data/data/com.tencent.ig/lib
cp -R /storage/emulated/0/IRGBrother/mod/libBugly.so /data/data/com.tencent.ig/lib
cp -R /storage/emulated/0/IRGBrother/mod/libgcloud.so /data/data/com.tencent.ig/lib
cp -R /storage/emulated/0/IRGBrother/mod/libGCloudVoice.so /data/data/com.tencent.ig/lib
cp -R /storage/emulated/0/IRGBrother/mod/libUE4.so /data/data/com.tencent.ig/lib
cp -R /storage/emulated/0/IRGBrother/mod/libgnustl_shared.so /data/data/com.tencent.ig/lib
cp -R /storage/emulated/0/IRGBrother/mod/libhelpshiftlistener.so /data/data/com.tencent.ig/lib
cp -R /storage/emulated/0/IRGBrother/mod/libigshare.so /data/data/com.tencent.ig/lib
cp -R /storage/emulated/0/IRGBrother/mod/liblbs.so /data/data/com.tencent.ig/lib
cp -R /storage/emulated/0/IRGBrother/mod/libTDataMaster.so /data/data/com.tencent.ig/lib
cp -R /storage/emulated/0/IRGBrother/mod/Active.sav /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
cp -R /storage/emulated/0/IRGBrother/mod/UserCustom.ini /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android
echo " Successfully.........." 
echo "Loading. . .
█ 1%
██ 10%
███ 20%
████ 30%
█████ 40%
██████ 50%
███████ 60%
████████ 70%
█████████ 80 %
██████████ 90%
Loading . . .
████████████100% Success"
echo "=========================="
echo "Change Permissions PUBG..."
echo "=========================="
sleep 1;
chmod -R 755 /data/data/com.tencent.ig/lib/liblbs.so
chmod -R 755 /data/data/com.tencent.ig/lib/libGCloudVoice.so
chmod -R 755 /data/data/com.tencent.ig/lib/libigshare.so
chmod -R 755 /data/data/com.tencent.ig/lib/libgnustl_shared.so
chmod -R 755 /data/data/com.tencent.ig/lib/libabase.so
chmod -R 755 /data/data/com.tencent.ig/lib/libgcloud.so
chmod -R 755 /data/data/com.tencent.ig/lib/libtersafe.so
chmod -R 755 /data/data/com.tencent.ig/lib/libhelpshiftlistener.so
chmod -R 755 /data/data/com.tencent.ig/lib/libIMSDK.so
chmod -R 755 /data/data/com.tencent.ig/lib/libUE4.so
chmod -R 755 /data/data/com.tencent.ig/lib/libtprt.so
chmod -R 755 /data/data/com.tencent.ig/lib/libBugly.so
chmod -R 755 /data/data/com.tencent.ig/lib/libTDataMaster.so
chmod -R 755 /data/data/com.tencent.ig/lib/libzip.so
chmod -R 755 /data/data/com.tencent.ig/lib/libzlib.so
echo " Successfully.......... "
echo "Loading. . .
█ 1%
██ 10%
███ 20%
████ 30%
█████ 40%
██████ 50%
███████ 60%
████████ 70%
█████████ 80 %
██████████ 90%
Loading . . .
████████████100% Success"
echo "=========================="
echo "Change Frezing Databases PUBG..."
echo "=========================="
sleep 1;
chmod -R 000 /data/data/com.tencent.ig/databases/__hs__db_issues
chmod -R 000 /data/data/com.tencent.ig/databases/__hs__db_key_values
chmod -R 000 /data/data/com.tencent.ig/databases/__hs__db_properties
chmod -R 000 /data/data/com.tencent.ig/databases/__hs_db_helpshift_users
chmod -R 000 /data/data/com.tencent.ig/databases/__hs__db_support_key_values
chmod -R 000 /data/data/com.tencent.ig/databases/__hs__db_support_key_values
chmod -R 000 /data/data/com.tencent.ig/databases/__hs_db_helpshift_users
chmod -R 000 /data/data/com.tencent.ig/databases/pri_tencent_analysis.db
chmod -R 000 /data/data/com.tencent.ig/databases/tencent_analysis.db
chmod -R 000 /data/data/com.tencent.ig/databases/tencent_analysis.db
chmod -R 000 /data/data/com.tencent.ig/databases/pri_tencent_analysis.db
chmod -R 000 /data/data/com.tencent.ig/databases/__hs__db_sessions
chmod -R 000 /data/data/com.tencent.ig/databases/__hs_log_store
chmod -R 000 /data/data/com.tencent.ig/databases/tdm.db
chmod -R 000 /data/data/com.tencent.ig/databases/beacon_db
chmod -R 000 /data/data/com.tencent.ig/databases/bugly_db_
chmod -R 000 /data/data/com.tencent.ig/databases/config.db
chmod -R 000 /data/data/com.tencent.ig/databases/iMSDK.db
chmod -R 400 /data/data/com.tencent.ig/shared_prefs/com.tencent.ig.mta.cloudctr.xml
echo "Loading. . .
█ 1%
██ 10%
███ 20%
████ 30%
█████ 40%
██████ 50%
███████ 60%
████████ 70%
█████████ 80 %
██████████ 90%
Loading . . .
████████████100% Success"
echo "=========================="
echo "Removing Data PUBG..."
echo "=========================="
sleep 1;
rm -rf /storage/emulated/0/tencent
rm -rf /storage/emulated/0/.backups
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/cache
rm -rf /storage/emulated/0/MidasOversea
rm -rf /storage/emulated/0/QTAudioEngine
rm -rf /data/data/com.tencent.ig/code_cache
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/ca-bundle.pem 	  
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/tbslog  	  
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/cacheFile.txt	
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/vmpcloudconfig.json
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/ImageDownload
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/Engine
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/StatEventReportedFlag
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
rm -rf /data/data/com.tencent.ig/app_appcache
rm -rf /data/data/com.tencent.ig/app_bugly
rm -rf /data/data/com.tencent.ig/app_crashrecord
rm -rf /data/data/com.tencent.ig/cache
rm -rf /data/data/com.tencent.ig/code_cache
rm -rf /data/data/com.tencent.ig/files/iMSDK
rm -rf /data/data/com.tencent.ig/files/ss_tmp
rm -rf /data/data/com.tencent.ig/files/AppEventsLogger.persistedevents
rm -rf /data/data/com.tencent.ig/files/tpnlcache.data
rm -rf /data/data/com.tencent.ig/files/tss_app_915c.dat
rm -rf /data/data/com.tencent.ig/files/tss_cs_stat2.dat
rm -rf /data/data/com.tencent.ig/files/tss.i.m.dat
echo " Processing Complate "
echo " Done... "
echo "=========================="
uptime
echo " • Mode = Undetected •"
echo " • Antiban On •"
echo " • AntiReport On •"
echo " • Donasi Pulsa Seikhlasnya •"
echo " • 081248643334•"
echo "‡‡‡‡‡‡‡▄▄▄▄
‡‡‡‡‡‡‡‡‡‡‡█‡‡‡‡█
‡‡‡‡‡‡‡‡‡‡‡█‡‡‡‡█
‡‡‡‡‡‡‡‡‡‡█‡‡‡‡‡█
‡‡‡‡‡‡‡‡‡█‡‡‡‡‡‡█
██████▄▄█‡‡‡‡‡‡████████▄
▓▓▓▓▓▓█‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡█
▓▓▓▓▓▓█‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡█
▓▓▓▓▓▓█‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡█
▓▓▓▓▓▓█‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡█
▓▓▓▓▓▓█‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡█
▓▓▓▓▓▓█████‡‡‡‡‡‡‡‡‡‡‡‡██
█████‡‡‡‡‡‡‡██████████™