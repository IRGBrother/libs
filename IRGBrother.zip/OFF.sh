#Ariel Peterpan
echo "log clean........"
echo "----------×🔐CLEAR DATA PUBG🔐×----------"
package="com.tencent.ig"
path=$(pm path $package)
path=${path#*:}
cp $path /data/local/tmp
mv /data/local/tmp/{base.apk,dlied.apk}
mv /storage/emulated/0/Android/obb/{com.tencent.ig,com.tencent.igx}
mv /storage/emulated/0/Android/data/{com.tencent.ig,com.tencent.igx}
echo "Loading. . .
█ 1%
██ 10%
███ 20%
████ 30%
█████ 40%
██████ 50%
███████ 60%
████████ 70%
█████████ 80 %
██████████ 90%
Loading . . .
████████████100% Success"
pm uninstall com.tencent.ig
echo "============================"
echo "█ ▄ █ ▄ ▄ █ ▄ █ ▄ █"
echo "============================"
pm install /data/local/tmp/dlied.apk
mv /storage/emulated/0/Android/obb/{com.tencent.igx,com.tencent.ig}
mv /storage/emulated/0/Android/data/{com.tencent.igx,com.tencent.ig}
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/cache
rm -rf /storage/emulated/0/tencent
rm -rf /storage/emulated/0/.backups
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/ca-bundle.pem
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/cacheFile.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/tbslog
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Screenshots
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/vmpcloudconfig.json
echo "Clear Complete"
echo "💯created by Ilham maulana"
echo "❤Donasi Pulsa seikhlasya❤"
echo "081248643334"
echo "♥…♥
……..♥………..♥
…♥………………..♥
..♥………………….♥
.♥……………………♥… ……♥….♥
♥…………………….♥… ♥…………..♥
.♥…………………….♥.. ……………..♥
..♥…………………….♥. ……………♥
…♥…………………… ♥… ……….♥
…..♥…………………… ……….♥
……..♥………………… ……♥
………..♥…………….. ….♥
……………♥………….. .♥
………………♥……….♥
…………………♥…..♥
………………….♥..♥
……………………♥
……………………♥
…………………..♥"
sleep 5;
am start -n com.tencent.ig/com.epicgames.ue4.SplashActivity